<?php
include 'includes/header.php';
include 'includes/navbar.php';
include 'pages/home.php';
include 'includes/footer.php';
